﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCompressionGraphics.Model
{
    public enum CompressionMethod
    {
        Huffman = 1,
        ShanonFano = 2,
    }
}
